import json
import os
import requests
from typing import Dict, Any

def call_llm(system_message: str, user_message: str) -> Dict[str, Any]:
    """Call the configured LLM provider."""
    provider = os.environ['LLM_PROVIDER'].lower()
    
    if provider == 'deepseek':
        url = "https://api.deepseek.com/v1/chat/completions"
        api_key = os.environ['DEEPSEEK_API_KEY']
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": system_message},
                {"role": "user", "content": user_message}
            ]
        }
    elif provider == 'openai':
        url = "https://api.openai.com/v1/chat/completions"
        api_key = os.environ['OPENAI_API_KEY']
        payload = {
            "model": "gpt-4",
            "messages": [
                {"role": "system", "content": system_message},
                {"role": "user", "content": user_message}
            ]
        }
    elif provider == 'anthropic':
        url = "https://api.anthropic.com/v1/messages"
        api_key = os.environ['CLAUDE_API_KEY']
        payload = {
            "model": "claude-3-opus-20240229",
            "messages": [
                {"role": "system", "content": system_message},
                {"role": "user", "content": user_message}
            ]
        }
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}")

    headers = {"Authorization": f"Bearer {api_key}"}
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        chat_response = response.json()["choices"][0]["message"]["content"]
        return {"response": chat_response}
    else:
        raise Exception(f"API call failed: {response.text}")

def lambda_handler(event, context):
    """Lambda function to process an agent's request and generate a response."""
    try:
        agent_data = json.loads(event['agent_data'])
        prev_response = event.get('prev_response', '')
        
        system_message = agent_data.get('system_message', 'No system message found')
        user_message = agent_data.get('user_message', 'No user message found')
        
        full_message = user_message + " " + prev_response
        response_dict = call_llm(system_message, full_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'response': response_dict.get('response', 'No response found'),
                'node_id': event.get('node_id')
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
