import json
import os
from neo4j import GraphDatabase

def get_neo4j_driver():
    uri = os.environ['NEO4J_URI']
    user = os.environ['NEO4J_USER']
    password = os.environ['NEO4J_PASSWORD']
    return GraphDatabase.driver(uri, auth=(user, password))

def lambda_handler(event, context):
    """Lambda function to find the next agent in sequence."""
    try:
        node_id = event['node_id']
        
        driver = get_neo4j_driver()
        with driver.session() as session:
            query = """
            MATCH (a:Agent)-[:NEXT_AGENT]->(next:Agent)
            WHERE elementId(a) = $node_id
            RETURN elementId(next) AS next_agent_id
            """
            result = [record.data() for record in session.run(query, {"node_id": node_id})]
            driver.close()
            
            return {
                'statusCode': 200,
                'body': json.dumps({'next_agent_id': result[0]['next_agent_id'] if result else None})
            }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
